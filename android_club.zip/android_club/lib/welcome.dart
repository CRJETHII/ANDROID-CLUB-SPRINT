import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class MyWelcome extends StatefulWidget {
  const MyWelcome({Key? key}) : super(key: key);
  @override
  _MyWelcomeState createState() => _MyWelcomeState();
}

class _MyWelcomeState extends State<MyWelcome> {
  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assests/background.png'), fit: BoxFit.cover)),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Stack(
            children: [
              Container(
                padding: EdgeInsets.only(left: 150, top:150),
                child:
                Text('',
                  style: TextStyle(color: Colors.white, fontSize: 33),
                ),
              ),
              SingleChildScrollView(
                child: Container(
                  padding: EdgeInsets.only(top: MediaQuery.of(context).size.height*0.75),
                  child: Column(
                    children: [
                      TextField(
                        decoration: InputDecoration(
                            fillColor: Colors.amber,
                            hintText: 'Signup',
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(40)
                            )
                        ),
                      ),
                      TextField(
                        decoration: InputDecoration(
                            fillColor: Colors.red,
                            hintText: 'Login',
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(40)
                            )
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        )
    );

  }
}