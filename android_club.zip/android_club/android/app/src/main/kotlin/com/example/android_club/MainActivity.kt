package com.example.android_club

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
